﻿using System.Reflection.Metadata;

namespace _29_04_opgave
{

    public class Bill
    {
        

        private int _year;
        public int Year
        {
            get { return _year; }
            set { _year = value; }
        }
        public decimal Pris()

        {
            return 100000m;
        }
  
    }
               
}





